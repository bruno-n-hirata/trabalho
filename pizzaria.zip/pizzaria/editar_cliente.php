<?php
require_once 'Cliente.php';
require_once 'ClienteRepositorio.php';

$clienteRepositorio = new ClienteRepositorio();

if (!isset($_GET['id_cliente'])) {
    header("Location: listar_clientes.php");
    exit;
}

$id_cliente = (int) $_GET['id_cliente'];
$cliente = $clienteRepositorio->buscarPorId($id_cliente);

if (!$cliente) {
    echo "Cliente não encontrado!";
    exit;
}

if (isset($_POST['atualizar'])) {
    $cliente->setNome($_POST['nome']);
    $cliente->setTelefone($_POST['telefone']);

    try {
        $clienteRepositorio->atualizar($cliente);
        header('Location: listar_clientes.php');
        exit;
    } catch(PDOException $e) {
        echo "Erro ao atualizar cliente: " . $e->getMessage();
    }
}
?>

<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <title>Edição de Cliente</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
<div class="container">
    <h1>Edição de Cliente</h1>
    <div class="top-actions">
        <a href="listar_clientes.php" class="btn">Voltar para a Lista</a>
    </div>
    <form method="post" action="">
        <div class="form-group">
            <label>Nome do Cliente:</label>
            <input type="text" name="nome" value="<?php echo $cliente->getNome(); ?>" required>
        </div>
        <div class="form-group">
            <label>Telefone:</label>
            <input type="tel" name="telefone" pattern="[0-9]+" value="<?php echo $cliente->getTelefone(); ?>" required>
        </div>
        <div class="form-group">
            <button type="submit" name="atualizar" class="btn">Atualizar</button>
        </div>
    </form>
</div>
</body>
</html>
