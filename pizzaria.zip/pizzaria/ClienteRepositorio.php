<?php
require_once 'Cliente.php';
require_once 'conexao.php';

class ClienteRepositorio {
    private $pdo;

    public function __construct() {
        $this->pdo = Conexao::getConexao();
    }

    public function buscar($filtro_nome = '') {
        $sql = "SELECT * FROM cliente WHERE 1=1";
        if (!empty($filtro_nome)) {
            $sql .= " AND nome LIKE :filtro_nome";
        }

        $stmt = $this->pdo->prepare($sql);
        if (!empty($filtro_nome)) {
            $stmt->bindValue(':filtro_nome', "%{$filtro_nome}%");
        }
        $stmt->execute();

        $clientesData = $stmt->fetchAll(PDO::FETCH_ASSOC);
        $clientes = [];

        foreach ($clientesData as $data) {
            $cliente = new Cliente();
            $cliente->setIdCliente($data['id_cliente']);
            $cliente->setNome($data['nome']);
            $cliente->setTelefone($data['telefone']);
            $clientes[] = $cliente;
        }
        return $clientes;
    }

    public function buscarPorId($id_cliente) {
        $sql = "SELECT * FROM cliente WHERE id_cliente = :id_cliente";
        $stmt = $this->pdo->prepare($sql);
        $stmt->bindValue(':id_cliente', $id_cliente);
        $stmt->execute();
        $data = $stmt->fetch(PDO::FETCH_ASSOC);

        if ($data) {
            $cliente = new Cliente();
            $cliente->setIdCliente($data['id_cliente']);
            $cliente->setNome($data['nome']);
            $cliente->setTelefone($data['telefone']);
            return $cliente;
        }
        return null;
    }

    public function inserir(Cliente $cliente) {
        $sql = "INSERT INTO cliente (nome, telefone) VALUES (:nome, :telefone)";
        $stmt = $this->pdo->prepare($sql);
        $stmt->bindValue(':nome', $cliente->getNome());
        $stmt->bindValue(':telefone', $cliente->getTelefone());
        return $stmt->execute();
    }

    public function atualizar(Cliente $cliente) {
        $sql = "UPDATE cliente SET nome = :nome, telefone = :telefone WHERE id_cliente = :id_cliente";
        $stmt = $this->pdo->prepare($sql);
        $stmt->bindValue(':nome', $cliente->getNome());
        $stmt->bindValue(':telefone', $cliente->getTelefone());
        $stmt->bindValue(':id_cliente', $cliente->getIdCliente());
        return $stmt->execute();
    }

    public function excluir($id_cliente) {
        $this->pdo->beginTransaction();
        try {
            $sqlPizzaSabor = "DELETE FROM pizza_sabor WHERE id_pizza IN (SELECT id_pizza FROM pizza WHERE id_pedido IN (SELECT id_pedido FROM pedido WHERE id_cliente = :id_cliente))";
            $stmtPizzaSabor = $this->pdo->prepare($sqlPizzaSabor);
            $stmtPizzaSabor->bindValue(':id_cliente', $id_cliente);
            $stmtPizzaSabor->execute();

            $sqlPizza = "DELETE FROM pizza WHERE id_pedido IN (SELECT id_pedido FROM pedido WHERE id_cliente = :id_cliente)";
            $stmtPizza = $this->pdo->prepare($sqlPizza);
            $stmtPizza->bindValue(':id_cliente', $id_cliente);
            $stmtPizza->execute();

            $sqlPedido = "DELETE FROM pedido WHERE id_cliente = :id_cliente";
            $stmtPedido = $this->pdo->prepare($sqlPedido);
            $stmtPedido->bindValue(':id_cliente', $id_cliente);
            $stmtPedido->execute();

            $sql = "DELETE FROM cliente WHERE id_cliente = :id_cliente";
            $stmt = $this->pdo->prepare($sql);
            $stmt->bindValue(':id_cliente', $id_cliente);
            $stmt->execute();

            $this->pdo->commit();
            return true;
        } catch (PDOException $e) {
            $this->pdo->rollBack();
            throw $e;
        }
    }        
}
?>
