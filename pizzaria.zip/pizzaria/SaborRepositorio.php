<?php
require_once 'Sabor.php';
require_once 'conexao.php';

class SaborRepositorio {
    private $pdo;

    public function __construct() {
        $this->pdo = Conexao::getConexao();
    }

    public function buscar($filtro_nome = '') {
        $sql = "SELECT * FROM sabor WHERE 1=1";
        if (!empty($filtro_nome)) {
            $sql .= " AND nome_sabor LIKE :filtro_nome";
        }

        $stmt = $this->pdo->prepare($sql);
        if (!empty($filtro_nome)) {
            $stmt->bindValue(':filtro_nome', "%{$filtro_nome}%");
        }
        $stmt->execute();

        $saboresData = $stmt->fetchAll(PDO::FETCH_ASSOC);
        $sabores = [];

        foreach ($saboresData as $data) {
            $sabor = new Sabor();
            $sabor->setIdSabor($data['id_sabor']);
            $sabor->setNomeSabor($data['nome_sabor']);
            $sabor->setPreco($data['preco']);
            $sabores[] = $sabor;
        }
        return $sabores;
    }

    public function buscarPorId($id_sabor) {
        $sql = "SELECT * FROM sabor WHERE id_sabor = :id_sabor";
        $stmt = $this->pdo->prepare($sql);
        $stmt->bindValue(':id_sabor', $id_sabor);
        $stmt->execute();
        $data = $stmt->fetch(PDO::FETCH_ASSOC);

        if ($data) {
            $sabor = new Sabor();
            $sabor->setIdSabor($data['id_sabor']);
            $sabor->setNomeSabor($data['nome_sabor']);
            $sabor->setPreco($data['preco']);
            return $sabor;
        }
        return null;
    }

    public function inserir(Sabor $sabor) {
        $sql = "INSERT INTO sabor (nome_sabor, preco) VALUES (:nome_sabor, :preco)";
        $stmt = $this->pdo->prepare($sql);
        $stmt->bindValue(':nome_sabor', $sabor->getNomeSabor());
        $stmt->bindValue(':preco', $sabor->getPreco());
        return $stmt->execute();
    }

    public function atualizar(Sabor $sabor) {
        $sql = "UPDATE sabor SET nome_sabor = :nome_sabor, preco = :preco WHERE id_sabor = :id_sabor";
        $stmt = $this->pdo->prepare($sql);
        $stmt->bindValue(':nome_sabor', $sabor->getNomeSabor());
        $stmt->bindValue(':preco', $sabor->getPreco());
        $stmt->bindValue(':id_sabor', $sabor->getIdSabor());
        return $stmt->execute();
    }

    public function excluir($id_sabor) {
        $this->pdo->beginTransaction();
        try {
            $sqlPizzaSabor = "DELETE FROM pizza_sabor WHERE id_sabor = :id_sabor";
            $stmtPizzaSabor = $this->pdo->prepare($sqlPizzaSabor);
            $stmtPizzaSabor->bindValue(':id_sabor', $id_sabor);
            $stmtPizzaSabor->execute();

            $sql = "DELETE FROM sabor WHERE id_sabor = :id_sabor";
            $stmt = $this->pdo->prepare($sql);
            $stmt->bindValue(':id_sabor', $id_sabor);
            $stmt->execute();
            
            $this->pdo->commit();
            return true;
        } catch (PDOException $e) {
            $this->pdo->rollBack();
            throw $e;
        }
    }
}
?>
