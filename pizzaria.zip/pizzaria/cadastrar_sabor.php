<?php
require_once 'Sabor.php';
require_once 'SaborRepositorio.php';

$saborRepositorio = new SaborRepositorio();

if (isset($_POST['cadastrar'])) {
    $nome_sabor = $_POST['nome_sabor'];
    $preco = $_POST['preco'];

    $sabor = new Sabor();
    $sabor->setNomeSabor($nome_sabor);
    $sabor->setPreco($preco);

    try {
        $saborRepositorio->inserir($sabor);
        header('Location: listar_sabores.php');
        exit;
    } catch (PDOException $e) {
        echo "Erro ao cadastrar sabor: " . $e->getMessage();
    }
}
?>

<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <title>Cadastro de Sabor</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
<div class="container">
    <h1>Cadastro de Sabor</h1>
    <div class="top-actions">
        <a href="listar_sabores.php" class="btn">Voltar para a Lista</a>
    </div>
    <form method="post" action="">
        <div class="form-group">
            <label>Nome do Sabor:</label>
            <input type="text" name="nome_sabor" required>
        </div>
        <div class="form-group">
            <label>Preço:</label>
            <input type="number" step="0.01" name="preco" required>
        </div>
        <div class="form-group">
            <button type="submit" name="cadastrar" class="btn">Cadastrar</button>
        </div>
    </form>
</div>
</body>
</html>
