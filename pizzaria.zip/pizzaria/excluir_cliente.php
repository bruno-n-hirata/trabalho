<?php
require_once 'ClienteRepositorio.php';

$clienteRepositorio = new ClienteRepositorio();

if (!isset($_GET['id_cliente'])) {
    header("Location: listar_clientes.php");
    exit;
}

$id_cliente = (int) $_GET['id_cliente'];

try {
    $clienteRepositorio->excluir($id_cliente);
    header("Location: listar_clientes.php");
    exit;
} catch(PDOException $e) {
    echo "Erro ao excluir cliente: " . $e->getMessage();
}
?>
