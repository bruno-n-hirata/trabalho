<?php
require_once 'SaborRepositorio.php';

$saborRepositorio = new SaborRepositorio();

$filtro_nome = "";
if (isset($_GET['buscar'])) {
    $filtro_nome = $_GET['filtro_nome'];
}

$sabores = $saborRepositorio->buscar($filtro_nome);
?>

<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <title>Lista de Sabores</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
<div class="container">
    <h1>Lista de Sabores</h1>
    <div class="top-actions">
        <a href="index.php" class="btn">Página Inicial</a>
        <a href="cadastrar_sabor.php" class="btn">Cadastrar Novo Sabor</a>
    </div>
    <form method="get" action="" class="search-form">
        <input type="search" name="filtro_nome" placeholder="Pesquise por nome" value="<?php echo htmlspecialchars($filtro_nome); ?>">
        <button type="submit" name="buscar" class="btn">Buscar</button>
    </form>
    <div class="table-wrapper">
        <table>
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Nome do Sabor</th>
                    <th>Preço</th>
                    <th>Ações</th>
                </tr>
            </thead>
            <tbody>
            <?php foreach($sabores as $sabor): ?>
                <tr>
                    <td><?php echo $sabor->getIdSabor(); ?></td>
                    <td><?php echo $sabor->getNomeSabor(); ?></td>
                    <td><?php echo $sabor->getPreco(); ?></td>
                    <td>
                        <a href="editar_sabor.php?id_sabor=<?php echo $sabor->getIdSabor(); ?>" class="btn">Editar</a>
                        <a href="excluir_sabor.php?id_sabor=<?php echo $sabor->getIdSabor(); ?>" class="btn btn-danger"
                           onclick="return confirm('Tem certeza que deseja excluir este sabor?');">
                           Excluir
                        </a>
                    </td>
                </tr>
            <?php endforeach; ?>
            </tbody>
        </table>
    </div>
</div>
</body>
</html>
