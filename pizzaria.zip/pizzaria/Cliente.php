<?php
class Cliente {
    private $id_cliente;
    private $nome;
    private $telefone;

    public function getIdCliente() {
        return $this->id_cliente;
    }

    public function getNome() {
        return $this->nome;
    }

    public function getTelefone() {
        return $this->telefone;
    }

    public function setIdCliente($id_cliente) {
        $this->id_cliente = $id_cliente;
    }

    public function setNome($nome) {
        $this->nome = $nome;
    }

    public function setTelefone($telefone) {
        $this->telefone = $telefone;
    }
}
?>
