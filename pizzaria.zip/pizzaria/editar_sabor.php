<?php
require_once 'Sabor.php';
require_once 'SaborRepositorio.php';

$saborRepositorio = new SaborRepositorio();

if (!isset($_GET['id_sabor'])) {
    header("Location: listar_sabores.php");
    exit;
}

$id_sabor = (int) $_GET['id_sabor'];
$sabor = $saborRepositorio->buscarPorId($id_sabor);

if (!$sabor) {
    echo "Sabor não encontrado!";
    exit;
}

if (isset($_POST['atualizar'])) {
    $sabor->setNomeSabor($_POST['nome_sabor']);
    $sabor->setPreco($_POST['preco']);

    try {
        $saborRepositorio->atualizar($sabor);
        header('Location: listar_sabores.php');
        exit;
    } catch(PDOException $e) {
        echo "Erro ao atualizar sabor: " . $e->getMessage();
    }
}
?>

<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <title>Edição de Sabor</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
<div class="container">
    <h1>Edição de Sabor</h1>
    <div class="top-actions">
        <a href="listar_sabores.php" class="btn">Voltar para a Lista</a>
    </div>
    <form method="post" action="">
        <div class="form-group">
            <label>Nome do Sabor:</label>
            <input type="text" name="nome_sabor" value="<?php echo $sabor->getNomeSabor(); ?>" required>
        </div>
        <div class="form-group">
            <label>Preço:</label>
            <input type="number" step="0.01" name="preco" value="<?php echo $sabor->getPreco(); ?>" required>
        </div>
        <div class="form-group">
            <button type="submit" name="atualizar" class="btn">Atualizar</button>
        </div>
    </form>
</div>
</body>
</html>
