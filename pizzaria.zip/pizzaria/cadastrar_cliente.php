<?php
require_once 'Cliente.php';
require_once 'ClienteRepositorio.php';

$clienteRepositorio = new ClienteRepositorio();

if (isset($_POST['cadastrar'])) {
    $nome = $_POST['nome'];
    $telefone = $_POST['telefone'];

    $cliente = new Cliente();
    $cliente->setNome($nome);
    $cliente->setTelefone($telefone);

    try {
        $clienteRepositorio->inserir($cliente);
        header('Location: listar_clientes.php');
        exit;
    } catch (PDOException $e) {
        echo "Erro ao cadastrar cliente: " . $e->getMessage();
    }
}
?>

<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <title>Cadastro de Cliente</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
<div class="container">
    <h1>Cadastro de Cliente</h1>
    <div class="top-actions">
        <a href="listar_clientes.php" class="btn">Voltar para a Lista</a>
    </div>
    <form method="post" action="">
        <div class="form-group">
            <label>Nome do Cliente:</label>
            <input type="text" name="nome" required>
        </div>
        <div class="form-group">
            <label>Telefone:</label>
            <input type="tel" name="telefone" pattern="[0-9]+" required>
        </div>
        <div class="form-group">
            <button type="submit" name="cadastrar" class="btn">Cadastrar</button>
        </div>
    </form>
</div>
</body>
</html>
