<?php
class Sabor {
    private $id_sabor;
    private $nome_sabor;
    private $preco;

    public function getIdSabor() {
        return $this->id_sabor;
    }

    public function getNomeSabor() {
        return $this->nome_sabor;
    }

    public function getPreco() {
        return $this->preco;
    }

    public function setIdSabor($id_sabor) {
        $this->id_sabor = $id_sabor;
    }

    public function setNomeSabor($nome_sabor) {
        $this->nome_sabor = $nome_sabor;
    }

    public function setPreco($preco) {
        $this->preco = $preco;
    }
}
?>
