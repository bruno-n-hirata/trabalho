<?php

class Conexao {
    private static $instance;

    public static function getConexao() {
        if(!isset(self::$instance)) {
            try {
                $host = '127.0.0.1';
                $dbName = 'pizzaria';
                $usuario = 'root';
                $senha = '';
                self::$instance = new PDO("mysql:host={$host};dbname={$dbName};charset=utf8", $usuario, $senha);
                self::$instance->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
            } catch(PDOException $e) {
                echo "Erro ao conectar: " . $e->getMessage();
                exit;
            }
        }
        return self::$instance;
    }
}
?>
