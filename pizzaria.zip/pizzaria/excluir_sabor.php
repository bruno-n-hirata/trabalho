<?php
require_once 'SaborRepositorio.php';

$saborRepositorio = new SaborRepositorio();

if (!isset($_GET['id_sabor'])) {
    header("Location: listar_sabores.php");
    exit;
}

$id_sabor = (int) $_GET['id_sabor'];

try {
    $saborRepositorio->excluir($id_sabor);
    header("Location: listar_sabores.php");
    exit;
} catch(PDOException $e) {
    echo "Erro ao excluir sabor: " . $e->getMessage();
}
?>
