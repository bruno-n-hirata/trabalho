<?php
require_once 'ClienteRepositorio.php';

$clienteRepositorio = new ClienteRepositorio();

$filtro_nome = "";
if (isset($_GET['buscar'])) {
    $filtro_nome = $_GET['filtro_nome'];
}

$clientes = $clienteRepositorio->buscar($filtro_nome);
?>

<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <title>Lista de Clientes</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
<div class="container">
    <h1>Lista de Clientes</h1>
    <div class="top-actions">
        <a href="index.php" class="btn">Página Inicial</a>
        <a href="cadastrar_cliente.php" class="btn">Cadastrar Novo Cliente</a>
    </div>
    <form method="get" action="" class="search-form">
        <input type="search" name="filtro_nome" placeholder="Pesquise por nome" value="<?php echo htmlspecialchars($filtro_nome); ?>">
        <button type="submit" name="buscar" class="btn">Buscar</button>
    </form>
    <div class="table-wrapper">
        <table>
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Nome do Cliente</th>
                    <th>Telefone</th>
                    <th>Ações</th>
                </tr>
            </thead>
            <tbody>
            <?php foreach($clientes as $cliente): ?>
                <tr>
                    <td><?php echo $cliente->getIdCliente(); ?></td>
                    <td><?php echo $cliente->getNome(); ?></td>
                    <td><?php echo $cliente->getTelefone(); ?></td>
                    <td>
                        <a href="editar_cliente.php?id_cliente=<?php echo $cliente->getIdCliente(); ?>" class="btn">Editar</a>
                        <a href="excluir_cliente.php?id_cliente=<?php echo $cliente->getIdCliente(); ?>" class="btn btn-danger"
                           onclick="return confirm('Tem certeza que deseja excluir este cliente?');">
                           Excluir
                        </a>
                    </td>
                </tr>
            <?php endforeach; ?>
            </tbody>
        </table>
    </div>
</div>
</body>
</html>
