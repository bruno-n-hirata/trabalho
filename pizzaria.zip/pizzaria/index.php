<?php
?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <title>Página Inicial</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
<div class="container">
    <h1>Bem-vindo à Pizzaria Sabor &amp; Arte</h1>
    <p class="subtitle">Gerencie os cadastros de sabores e clientes.</p>
    <ul class="menu-list">
        <li>
            <a href="listar_sabores.php" class="btn">Sabores</a>
        </li>
        <li>
            <a href="listar_clientes.php" class="btn">Clientes</a>
        </li>
    </ul>
    <div class="footer-text">
        &copy; <?php echo date('Y'); ?> | Pizzaria Sabor &amp; Arte
    </div>
</div>
</body>
</html>
